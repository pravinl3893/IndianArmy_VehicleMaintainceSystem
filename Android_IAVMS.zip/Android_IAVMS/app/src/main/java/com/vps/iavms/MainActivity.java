package com.vps.iavms;

import android.app.ActivityManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener
{

    private Map<String,String> user; //for storing logged in user info
    private SessionManager sm;
    private Fragment fragment = null;
    private Fragment nearbyunit;
    private Fragment notification_list;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        sm=new SessionManager(this);
        notification_list=new NotificationList();
        nearbyunit=new NearbyUnits();
         /* checking user session */
        if(!sm.checkLogin())
        {
            finish();
        }
        else
            {
           if(!isServiceRunning())
                {
                Intent i = new Intent(MainActivity.this, ClientService.class);
                startService(i);
            }
            user = sm.getUserDetails();
            setContentView(R.layout.main_activity);
            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.setDrawerListener(toggle);
            toggle.syncState();


            NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
            View header = navigationView.inflateHeaderView(R.layout.nav_header_main);           //getting navigation header object
            TextView emailid_textview = (TextView) header.findViewById(R.id.emailid_textview);  //getting textview from navigation header
            emailid_textview.setText(user.get(SessionManager.Key_DRIVER_NAME)+"("+user.get(SessionManager.KEY_VEHICLE_NO)+")");
            navigationView.setNavigationItemSelectedListener(this);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            String notif=getIntent().getStringExtra("isNotificationList");
            if(notif!=null)
            {
                if (notif.equals("TRUE"))
                {
                    fragment = notification_list;
                }
            }
            else
            {
                fragment=new CarDiary();
            }
            ft.replace(R.id.content_frame,fragment );
            ft.commit();
        }
    }
    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)){
            if("com.vps.iavms.ClientService".equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item)
    {

        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.car_diary)
        {
            fragment=new CarDiary();
        }
        else  if (id == R.id.logbook)
        {
            fragment=new LogBook();

        }
        else if (id == R.id.major_issue)
        {
            fragment=new MajorIssue();

        }
        else if (id == R.id.nearby_units)
        {
            fragment=nearbyunit;
        }
        else if (id == R.id.notification_menu)
        {
            fragment=notification_list;
        }
        else if (id == R.id.logout)
        {

            sm.logoutUser();
            if(isServiceRunning())
            {
                Intent i = new Intent(MainActivity.this, ClientService.class);
                stopService(i);
            }
         //   Toast.makeText(this,"Logout successful",Toast.LENGTH_SHORT).show();

        }

        if (fragment != null)
        {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
