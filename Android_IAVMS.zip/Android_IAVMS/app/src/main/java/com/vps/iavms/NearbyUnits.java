package com.vps.iavms;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static android.content.Context.LOCATION_SERVICE;


public class NearbyUnits extends Fragment implements LocationListener, OnMapReadyCallback {
    private GoogleMap mMap;
    private RequestQueue queue;
    private String url = "http://"+ServerUrl.ip+"/android/nearbyunits.php";
    private GoogleMap gm;
    private LocationManager locationManager;
    private int updateInterval = 200000;
    Geocoder geocoder;

    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.nearby_units, container, false);
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.nearby_unit_map);
        mapFragment.getMapAsync(this);
        locationManager = (LocationManager) getActivity().getSystemService(LOCATION_SERVICE);
        geocoder = new Geocoder(getContext(), Locale.getDefault());
        if (!(Build.VERSION.SDK_INT < Build.VERSION_CODES.M)) ;
        {

            if (ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                android.Manifest.permission.ACCESS_COARSE_LOCATION},
                        1111);
            }
            else
                {
                //check for gps enabled or not
                if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) && !locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) //if gps is disabled
                {
                    displayPromptForEnablingGPS(getActivity());
                } else {
                    if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, updateInterval, 0, this);
                    } else {
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, updateInterval, 0, this);

                    }
                }
            }
        }

        return view;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Nearby units");
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);



    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        switch (requestCode)
        {
            case 1111:
            {
                if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    if ( !locationManager.isProviderEnabled( LocationManager.GPS_PROVIDER ) )
                    {
                        displayPromptForEnablingGPS(getActivity());
                    }
                    else
                    {
                        if (locationManager.isProviderEnabled( LocationManager.NETWORK_PROVIDER)) {
                            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, updateInterval, 0, this);
                        }
                        else
                        {
                            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, updateInterval, 0, this);

                        }
                    }
                }
                else
                {
                    Toast.makeText(getContext(), "Allow permission to access gps device", Toast.LENGTH_SHORT).show();
                    requestPermissions( new String[]{
                                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                                    android.Manifest.permission.ACCESS_COARSE_LOCATION },
                                    1111);
                }

            }

        }
    }


/* Location Listener Methods */
    @SuppressLint("MissingPermission")
    @Override
    public void onLocationChanged(Location location)
    {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        LatLng latLng = new LatLng(latitude, longitude);
        mMap.setMyLocationEnabled(true);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 10));
        Toast.makeText(getContext(),"Curent Location: "+getAddress(latitude,longitude),Toast.LENGTH_SHORT).show();
        setNearBy(latitude,longitude);
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
    }

    @Override
    public void onProviderEnabled(String s) {
    }

    @Override
    public void onProviderDisabled(String s) {
    }
/*end of location listener methods */

//get nearby location from server and set pin on map
public void setNearBy(final double curr_lat,final double curr_long)
{
            queue = Volley.newRequestQueue(getContext());
            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response)
                        {
                               if (response.trim().equals("[]")) {
                                Toast.makeText(getContext(), "No nearby unit found", Toast.LENGTH_LONG).show();

                            }
                            else
                            {
                                try {

                                    JSONArray jsonArray = new JSONArray(response);
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                                        double lat = Double.parseDouble(jsonObject.getString("lati"));
                                        double longi = Double.parseDouble(jsonObject.getString("longi"));
                                        LatLng loc = new LatLng(lat, longi);
                                        int ind=jsonObject.getString("dist").indexOf('.');
                                        mMap.addMarker(new MarkerOptions().position(loc).title(getAddress(lat,longi)+": " + jsonObject.getString("dist").substring(0,ind+2)+" km"));
                                    }


                                } catch (Exception e) {
                                    Toast.makeText(getContext(), e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                                }


                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getContext(),"Unable to connect to the server", Toast.LENGTH_LONG).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("LAT", Double.toString(curr_lat));
                    params.put("LONG", Double.toString(curr_long));

                    return params;
                }
            };
            queue.add(request);

        }

    public String getAddress(double lat, double lng)
    {
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            Address obj = addresses.get(0);
            return obj.getLocality();
        }
        catch (Exception e)
        {
          Toast.makeText(getContext(),e.getLocalizedMessage(),Toast.LENGTH_SHORT).show();
        }
        return null;
    }


    ///  alert for gps enable ////
    public static void displayPromptForEnablingGPS(final Activity activity)
    {
        final AlertDialog.Builder builder =new AlertDialog.Builder(activity);
        final String action = Settings.ACTION_LOCATION_SOURCE_SETTINGS;
        final String message = "Enable either GPS or any other location"
                + " service to find current location.  Click OK to go to"
                + " location services settings to let you do so.";
        builder.setMessage(message)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int id) {
                                activity.startActivity(new Intent(action));
                                d.dismiss();
                            }
                        });
        builder.create().show();
    }
}


