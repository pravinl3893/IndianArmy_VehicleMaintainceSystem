package com.vps.iavms;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.RecyclerViewHolder>
{

    Context context;
    NotificationData notificationData;
    SQLiteDatabase mydatabase;
    CustomAdapter customAdapter;
    CustomAdapter(Context context,NotificationData notificationData, SQLiteDatabase mydatabase)
    {
        super();
        this.context=context;
        this.notificationData=notificationData;
        this.mydatabase =mydatabase;
        customAdapter=this;
    }
    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_row,parent,false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view,context,notificationData,mydatabase,customAdapter);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position)
    {
        holder.title_et.setText(notificationData.get(position).get(0));
        if(notificationData.get(position).get(1).length()>36)
              holder.descr_et.setText(notificationData.get(position).get(1).substring(0,36)+"...");
        else
            holder.descr_et.setText(notificationData.get(position).get(1));
        if(!notificationData.get(position).get(2).equals("NEW"))
        {
            holder.iv.setVisibility(View.INVISIBLE);
        }
        else
        {
            if(holder.iv.getVisibility()==View.INVISIBLE) {
                holder.iv.setVisibility(View.VISIBLE);
                holder.iv.setImageResource(R.drawable.new_notif);
            }
        }

    }

    @Override
    public int getItemCount() {
        return notificationData.length();
    }

    public static class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView title_et;
        TextView descr_et;
        ImageView iv;
        Context ctx;
        NotificationData data;
        SQLiteDatabase mydatabase;
        CustomAdapter cas;
        public RecyclerViewHolder(View itemView,Context ctx,NotificationData data, SQLiteDatabase mydatabase,CustomAdapter ca)
        {
            super(itemView);
            itemView.setOnClickListener(this);
            this.data=data;
            this.mydatabase=mydatabase;
            title_et = (TextView) itemView.findViewById(R.id.notif_et);
            descr_et =  (TextView) itemView.findViewById(R.id.discr_et);
            iv=(ImageView)itemView.findViewById(R.id.status_imgview);
            this.ctx = ctx;
            cas=ca;
        }

        @Override
        public void onClick(View view)
        {
            int pos = getAdapterPosition();
            if(data.get(pos).get(2).equals("NEW")) {
                try {
                    String id = data.get(pos).get(3);
                    NotificationManager notificationManager = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                    notificationManager.cancel(Integer.parseInt(id));
                    data.change(pos, "OLD");
                    if (mydatabase.isOpen())
                        mydatabase.execSQL("UPDATE notifications SET status='OLD' WHERE id='" + id + "';");
                } catch (Exception e)
                {
                    Toast.makeText(ctx,"CustomAdapter@RecycleViewHolder@onClick(): "+e.getLocalizedMessage(),Toast.LENGTH_LONG).show();

                }
            }
            Intent i=new Intent(ctx,NotificationViewActivity.class);
            i.putExtra("id","NULL");
            i.putExtra("title",data.get(pos).get(0));
            i.putExtra("details",data.get(pos).get(1));
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        }
    }
}
