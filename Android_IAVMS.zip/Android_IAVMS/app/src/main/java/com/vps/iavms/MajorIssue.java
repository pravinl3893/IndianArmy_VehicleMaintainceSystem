package com.vps.iavms;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MajorIssue extends Fragment
{
    private Button submit;
    private EditText issue_date,dis;
    private String url="http://"+ServerUrl.ip+"/android/majorissue.php";
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        return inflater.inflate(R.layout.major_issue, container, false);

    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Major Issue");
        issue_date=(EditText)view.findViewById(R.id.major_issue_date);
        new DateInputMask(issue_date,getContext());
        dis=(EditText)view.findViewById(R.id.major_issue_description);
        submit=(Button)view.findViewById(R.id.major_issue_submit_button);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = issue_date.getText().toString();
                if(date.length()<10 || date.contains("d") || date.contains("m") || date.contains("y") )
                {
                    Toast.makeText(getContext(),"Invalid date",Toast.LENGTH_SHORT).show();
                    issue_date.setText("");
                    return;
                } else {
                    date = date.substring(6) + "-" + date.substring(3, 5) + "-" + date.substring(0, 2);
                    String description = dis.getText().toString();
                    if (description.trim().isEmpty()) {
                        Toast.makeText(getContext(), "Description should't be empty", Toast.LENGTH_SHORT).show();

                    } else if (!description.matches("[a-zA-Z0-9 .,]*")) //checks if string contains symbol
                    {
                        Toast.makeText(getContext(), "Invalid description", Toast.LENGTH_SHORT).show();
                        dis.setText("");
                    } else {
                        SessionManager sm = new SessionManager(getContext());
                        final HashMap<String, String> data = new HashMap<String, String>();
                        data.put("vno", sm.getUserDetails().get(SessionManager.KEY_VEHICLE_NO));
                        data.put("date", date);
                        data.put("dis", description);

                        RequestQueue queue = Volley.newRequestQueue(getContext());
                        final ProgressDialog progress = new ProgressDialog(getContext());
                        progress.setTitle("Please wait..");
                        progress.setMessage("Submitting data");
                        progress.setCancelable(false);
                        progress.show();
                        StringRequest request = new StringRequest(Request.Method.POST, url,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {

                                        progress.dismiss();
                                        if (!response.equals("failed")) {
                                            Toast.makeText(getContext(), response, Toast.LENGTH_LONG).show();
                                        } else {
                                            Toast.makeText(getContext(), "Failed to submit data", Toast.LENGTH_LONG).show();
                                        }
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        // error
                                        progress.dismiss();
                                        Toast.makeText(getContext(), error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                                    }
                                }
                        ) {
                            @Override
                            protected Map<String, String> getParams() {

                                return data;
                            }
                        };
                        queue.add(request);
                    }

                }
            }
        });

    }
}