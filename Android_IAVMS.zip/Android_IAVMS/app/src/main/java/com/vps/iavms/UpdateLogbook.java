package com.vps.iavms;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class UpdateLogbook extends AppCompatActivity
{
    private WebView wv;
    @Override
    public void onCreate(Bundle b)
    {
        super.onCreate(b);
        setContentView(R.layout.show_logbook_record);
        wv=(WebView)findViewById(R.id.logbook_web_view);
        final ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("Please wait..");
        progress.setMessage("Loading");
        progress.setCancelable(false);
        progress.show();
        String url = "http://"+ServerUrl.ip+"/android/updatelogbook.php";
        String postData = null;
        try {
            postData = "vno=" + URLEncoder.encode(new SessionManager(getApplicationContext()).getUserDetails().get(SessionManager.KEY_VEHICLE_NO), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        wv.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView v,String url)
            {
                super.onPageFinished(v,url);
                progress.hide();
            }

        });
        wv.postUrl(url,postData.getBytes());
    }
}