package com.vps.iavms;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Pravin on 12/8/2017.
 */

public class GetLogbook
{
    private RequestQueue queue;
    private StringRequest request;
    private Map<String, String> data;
    private String url="http://"+ServerUrl.ip+"/android/getlogbook.php";
    private Context c;

   public ArrayList<String> dat;
    GetLogbook(Context c)
    {
        this.c=c;
        queue = Volley.newRequestQueue(c);
        data = new HashMap<String, String>();
        data.put("vno", new SessionManager(c).getUserDetails().get(SessionManager.KEY_VEHICLE_NO));
        queue = Volley.newRequestQueue(c);
    }
    public void getLogbookData()
    {
        StringRequest sr= new StringRequest(com.android.volley.Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.trim().contains("[") && response.trim().contains("]")) {
                            try
                            {
                                JSONArray jsonArray = new JSONArray(response);
                                dat=new ArrayList<String>(jsonArray.length());
                                for (int i = 0; i < jsonArray.length(); i++)
                                {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);                                                                                                   dat.add(jsonObject.getString("data"));
                                }
                            } catch (Exception e) {
                                Toast.makeText(c, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(c, "Unable to connect to the server", Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                return data;
            }

        };
        queue.add(sr);
    }
}
