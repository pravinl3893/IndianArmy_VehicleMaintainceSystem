package com.vps.iavms;


public class ServerUrl
{
    public static String ip="192.168.43.42";

}
