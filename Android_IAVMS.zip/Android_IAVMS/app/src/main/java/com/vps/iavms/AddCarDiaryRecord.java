package com.vps.iavms;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AddCarDiaryRecord extends AppCompatActivity
{
    private EditText nature_of_dutyet,date_et,from_et,to_et,km_run_et,discrption_et;
    private String nature_of_duty,date,from,to,km_run,discrption;
    private Button submit;

    String url="http://"+ServerUrl.ip+"/android/addcardiarydata.php";

    @Override
    public void onCreate(Bundle b)
    {
        super.onCreate(b);
        setContentView(R.layout.add_car_diary_record);
        nature_of_dutyet=(EditText)findViewById(R.id.nature_of_duty_et);
        date_et=(EditText)findViewById(R.id.date_et);
        new DateInputMask(date_et,getApplicationContext());
        from_et=(EditText)findViewById(R.id.from_et);
        to_et=(EditText)findViewById(R.id.to_et);
        km_run_et=(EditText)findViewById(R.id.km_run_et);
        discrption_et=(EditText)findViewById(R.id.discription_et);
        submit=(Button)findViewById(R.id.submit_car_diary_bt);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitToServer();
            }
        });
    }

    private void submitToServer()
    {
        nature_of_duty=nature_of_dutyet.getText().toString();
        date=date_et.getText().toString();
        from=from_et.getText().toString();
        to=to_et.getText().toString();
        km_run=km_run_et.getText().toString();
        discrption=discrption_et.getText().toString();
        if(nature_of_duty.trim().isEmpty() || date.trim().isEmpty() ||  from.trim().isEmpty() || to.trim().isEmpty() || km_run.trim().isEmpty() || discrption.trim().isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Empty fields are not allowed",Toast.LENGTH_SHORT).show();
        }
        else
        {
            if(date.length()<10 || date.contains("d") || date.contains("m") || date.contains("y") )
            {
                Toast.makeText(getApplicationContext(),"Invalid date",Toast.LENGTH_SHORT).show();
                date_et.setText("");
                return;
            }
            date=date.substring(6)+"-"+date.substring(3,5)+"-"+date.substring(0,2);
            SessionManager sm = new SessionManager(getApplicationContext());
            final HashMap<String, String> data = new HashMap<String, String>();
            data.put("nature", nature_of_duty);
            data.put("date", date);

            data.put("to", to);
            data.put("from", from);
            data.put("kmrun", km_run);
            data.put("des", discrption);
            data.put("vno", sm.getUserDetails().get(SessionManager.KEY_VEHICLE_NO));

            RequestQueue queue = Volley.newRequestQueue(this);
            final ProgressDialog progress = new ProgressDialog(this);
            progress.setTitle("Please wait..");
            progress.setMessage("Submitting data");
            progress.setCancelable(false);
            progress.show();
            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                            progress.dismiss();
                            if(!response.equals("There might be problem while uploading data..Please try again.."))
                            {
                                finish();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            progress.dismiss();
                            Toast.makeText(getApplicationContext(), "Unable to connect to the server", Toast.LENGTH_LONG).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {

                    return data;
                }
            };
            queue.add(request);
        }
    }

}
