package com.vps.iavms;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class DateInputMask implements TextWatcher {

private String current = "";
private String ddmmyyyy = "ddmmyyyy";
private Calendar cal = Calendar.getInstance();
private EditText input;
private Context context;
public DateInputMask(EditText input,Context context) {
    this.input = input;
    this.context=context;
    this.input.addTextChangedListener(this);
}

@Override
public void beforeTextChanged(CharSequence s, int start, int count, int after) {

}

@Override
public void onTextChanged(CharSequence s, int start, int before, int count) {
    if (s.toString().equals(current)) {
        return;
    }

    String clean = s.toString().replaceAll("[^\\d.]|\\.", "");
    String cleanC = current.replaceAll("[^\\d.]|\\.", "");

    int cl = clean.length();
    int sel = cl;
    for (int i = 2; i <= cl && i < 6; i += 2) {
        sel++;
    }
    //Fix for pressing delete next to a forward slash
    if (clean.equals(cleanC)) sel--;

    if (clean.length() < 8){
        clean = clean + ddmmyyyy.substring(clean.length());
    }else{
        //This part makes sure that when we finish entering numbers
        //the date is correct, fixing it otherwise
        int day  = Integer.parseInt(clean.substring(0,2));
        int mon  = Integer.parseInt(clean.substring(2,4));
        int year = Integer.parseInt(clean.substring(4,8));
        if (mon>12 || mon<1 || day>31 || day<1 || year >2800 || year<2000)
        {
            Toast.makeText(context,"Invalid date",Toast.LENGTH_LONG).show();
            clean="";
        }
        else {
            cal.set(Calendar.MONTH, mon - 1);
            year = (year < 1900) ? 1900 : (year > 2800) ? 2800 : year;
            cal.set(Calendar.YEAR, year);
            // ^ first set year for the line below to work correctly
            //with leap years - otherwise, date e.g. 29/02/2012
            //would be automatically corrected to 28/02/2012

            day = (day > cal.getActualMaximum(Calendar.DATE)) ? cal.getActualMaximum(Calendar.DATE) : day;
            clean = String.format("%02d%02d%04d", day, mon, year);
        }

    }
    if(!clean.equals("")) {
        clean = String.format("%s/%s/%s", clean.substring(0, 2),
                clean.substring(2, 4),
                clean.substring(4, 8));

        sel = sel < 0 ? 0 : sel;
        current = clean;
        input.setText(current);
        input.setSelection(sel < current.length() ? sel : current.length());
    }
    else
    {
        input.setText("");
        current="";
    }
}

@Override
public void afterTextChanged(Editable s)
{

}
}