package com.vps.iavms;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;

public class NotificationList extends Fragment
{
   private RecyclerView rv;
   private NotificationData notificationData;
   private SQLiteDatabase mydatabase;
   private CustomAdapter adapter;
   private Cursor res;
   public final int day_mili_seconds= (int)TimeUnit.MINUTES.toMillis(2);

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.notification_list, container, false);

    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ClientService.notificationList = this;
        getActivity().setTitle("Notifications");
        rv = (RecyclerView) view.findViewById(R.id.recv);
        rv.addItemDecoration(new SimpleDividerItemDecoration(getActivity()));
        notificationData = new NotificationData();
        mydatabase = getActivity().openOrCreateDatabase("IAVMD.db", Context.MODE_PRIVATE, null);
        res = mydatabase.rawQuery("select * from notifications", null);
        res.moveToLast();
        while(res.isBeforeFirst() == false)
        {
            String insertion_time=res.getString(0);
            if(Double.parseDouble(insertion_time)+day_mili_seconds<(int)System.currentTimeMillis())
            {
                mydatabase.execSQL("delete from notifications where id='"+insertion_time+"'");
            }
            else {
                notificationData.add(res.getString(0), res.getString(1), res.getString(2), res.getString(3));
            }
            res.moveToPrevious();
        }
        res.close();
        adapter = new CustomAdapter(getActivity(), notificationData, mydatabase);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(layoutManager);
        rv.setAdapter(adapter);
    }
    @Override
    public void onDestroy()
    {
        super.onDestroy();
        if(mydatabase!=null)
            if(mydatabase.isOpen())
                    mydatabase.close();
    }
    @Override

    public void onResume()
    {
        super.onResume();
        refresh();

    }
    public void refresh()
    {
        try {
            res = mydatabase.rawQuery("select * from notifications", null);
            res.moveToLast();
            notificationData = new NotificationData();
            while (res.isBeforeFirst() == false) {
                String insertion_time = res.getString(0);
                if (Double.parseDouble(insertion_time) + day_mili_seconds < (int) System.currentTimeMillis()) {
                    if (mydatabase.isOpen())
                        mydatabase.execSQL("delete from notifications where id='" + insertion_time + "'");

                } else {
                    notificationData.add(res.getString(0), res.getString(1), res.getString(2), res.getString(3));
                }
                res.moveToPrevious();
            }
            res.close();
            adapter = new CustomAdapter(getActivity(), notificationData, mydatabase);
            rv.setAdapter(adapter);
            rv.refreshDrawableState();
        }
        catch (Exception e)
        {
            Log.d("NL",e.getLocalizedMessage());

        }

    }

    public class SimpleDividerItemDecoration extends RecyclerView.ItemDecoration {
        private Drawable mDivider;

        public SimpleDividerItemDecoration(Context context) {
            mDivider = context.getResources().getDrawable(R.drawable.line_divider);
        }

        @Override
        public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
            int left = parent.getPaddingLeft();
            int right = parent.getWidth() - parent.getPaddingRight();

            int childCount = parent.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View child = parent.getChildAt(i);

                RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();

                int top = child.getBottom() + params.bottomMargin;
                int bottom = top + mDivider.getIntrinsicHeight();

                mDivider.setBounds(left, top, right, bottom);
                mDivider.draw(c);
            }
        }
    }

}

