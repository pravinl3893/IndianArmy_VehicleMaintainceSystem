package com.vps.iavms;


import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

public class NotificationViewActivity extends AppCompatActivity
{
    private Intent i;
    private TextView title_tv,details_tv;
    private String title,details;
    private SQLiteDatabase mydatabase;
    private Cursor res;
    @Override
    public void onCreate(Bundle b)
    {
        super.onCreate(b);
        setContentView(R.layout.notification_view_activity);
        i=getIntent();
        String id=i.getStringExtra("id");
        if(id.equals("NULL")) {
             title = i.getStringExtra("title");
             details = i.getStringExtra("details");
        }
        else
        {
            try {
                mydatabase = openOrCreateDatabase("IAVMD.db", Context.MODE_PRIVATE, null);
                mydatabase.execSQL("UPDATE notifications SET status='OLD' WHERE id='" + id + "';");
                res = mydatabase.rawQuery("select title,description from notifications where id='" + id + "'", null);
                if (res.isAfterLast() == false) {
                    res.moveToFirst();
                    title = res.getString(0);
                    details = res.getString(1);
                }
            }catch (Exception e)
            {
                Toast.makeText(getApplicationContext(),"NotificationViewActivity: "+e.getLocalizedMessage(),Toast.LENGTH_LONG).show();
            }

        }

        title_tv=(TextView)findViewById(R.id.notification_title_tv);
        details_tv=(TextView)findViewById(R.id.details_tv);
        title_tv.setText(title);
        details_tv.setText(details);

    }


    public void onPause()
    {
    super.onPause();
    if(res!=null)
    res.close();
    if(mydatabase!=null)
        if(mydatabase.isOpen())
            mydatabase.close();
    finish();
    }

}
