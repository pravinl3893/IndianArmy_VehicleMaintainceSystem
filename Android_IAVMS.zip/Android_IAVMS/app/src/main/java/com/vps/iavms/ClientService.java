package com.vps.iavms;


import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class ClientService extends Service
{
    private Notification notification;
    private Thread t;
    public static NotificationList notificationList;
    private String url="http://"+ServerUrl.ip+"/android/generatenotification.php";
    private String motion_sensor_url="http://"+ServerUrl.ip+"/android/motionandroid.php";
    private String temperature_sensor_url="http://"+ServerUrl.ip+"/android/temperaturendroid.php";
    SQLiteDatabase mydatabase;
    public int thread_flag=1;

    public ClientService()
    {
        super();
        t=new Request();

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notification = new Notification(getApplicationContext());
        mydatabase =openOrCreateDatabase("IAVMD.db",MODE_PRIVATE,null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS notifications(id VARCHAR,title VARCHAR,description VARCHAR,status VARCHAR);");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
    super.onStartCommand(intent,flags,startId);
        if (t==null) {
            t = new Request();
            t.start();

        }
        else
        {
            t.start();

        }
        return START_STICKY;
    }


    class Request extends Thread
    {
        RequestQueue queue;
        StringRequest request;
        Map<String, String> data;
        Thread v;
        public  void init()
        {
            data = new HashMap<String, String>();
            data.put("vno", new SessionManager(getApplicationContext()).getUserDetails().get(SessionManager.KEY_VEHICLE_NO));
            queue = Volley.newRequestQueue(getApplicationContext());

        }

        StringRequest getStringRequest(String url)
        {
            return new StringRequest(com.android.volley.Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            if(response.trim().contains("[")&&response.trim().contains("]"))
                           {
                               try {
                                   JSONArray jsonArray = new JSONArray(response);
                                   for (int i = 0; i < jsonArray.length(); i++) {
                                       JSONObject jsonObject = jsonArray.getJSONObject(i);
                                       String title=jsonObject.getString("title");
                                       String remaining_days=jsonObject.getString("remaining_days");
                                       String details=null;
                                       if(!remaining_days.trim().equals("0")) {
                                           details = jsonObject.getString("notification_details") + " " + remaining_days;
                                       }
                                       else
                                       {
                                           details = jsonObject.getString("notification_details");
                                       }
                                       String id= Integer.toString(notification.genrateNotification(title,details));
                                       try {
                                           mydatabase.execSQL("INSERT INTO notifications VALUES('" + id + "' ,'" + title + "','" + details + "','NEW');");
                                       }
                                       catch (Exception e)
                                       {
                                           Log.i("Tay",e.getLocalizedMessage());
                                       }
                                       }
                               } catch (Exception e) {
                                   Toast.makeText(getApplicationContext(),e.getLocalizedMessage(),Toast.LENGTH_LONG).show();  }
                               if(notificationList!=null)
                                   notificationList.refresh();

                           }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Toast.makeText(getApplicationContext(), "Unable to connect to the server", Toast.LENGTH_LONG).show();
                        }
                    })
            {
                @Override
                protected Map<String, String> getParams()
                {

                    return data;
                }

            };
        }
        @Override
        public void run()
        {
            init();
            new Thread()
            {
                @Override
                public void run()
                {
                    queue.add(getStringRequest(url));
                    try {
                        sleep(86400000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }.start();
            while (thread_flag==1)
            {
                try
                {
                    queue.add(getStringRequest(motion_sensor_url));
                    queue.add(getStringRequest(temperature_sensor_url));
                    sleep(3000);
                }
                catch (InterruptedException e)
                {
                    Toast.makeText(getApplicationContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        }
    }
    @Override
        public void onDestroy()
        {
        super.onDestroy();
        if(mydatabase!=null)
            mydatabase.close();
        if(t!=null) {
            if (t.isAlive())
            {
                thread_flag=0;
            }
        }
    }
}






