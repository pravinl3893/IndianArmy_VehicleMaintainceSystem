package com.vps.iavms;

import java.util.ArrayList;

public class NotificationData
{
    private ArrayList<ArrayList<String>> data;
    private String notificationTitle;
    private String notificationDetails;
    private String id;
    NotificationData()
    {
        data=new ArrayList<ArrayList<String>>();
    }
    public void add(String id,String notificationTitle,String notificationDetails,String status)
    {
        ArrayList<String> a=new ArrayList<String>();
        a.add(notificationTitle);
        a.add(notificationDetails);
        a.add(status);
        a.add(id);
        data.add(a);
    }
    public void change(int postion ,String value)
    {
        data.get(postion).set(2,value);
    }
    public ArrayList<String> get(int position)
    {
        return data.get(position);
    }
    public int length()
    {
        return data.size();
    }
}
