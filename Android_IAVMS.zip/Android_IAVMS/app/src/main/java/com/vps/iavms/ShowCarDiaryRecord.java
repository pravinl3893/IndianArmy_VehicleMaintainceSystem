package com.vps.iavms;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * Created by S_G_Madankar on 03-Nov-17.
 */

public class ShowCarDiaryRecord extends AppCompatActivity
{
    private WebView wv;
    @Override
    public void onCreate(Bundle b)
    {
        super.onCreate(b);
        setContentView(R.layout.show_cardiary_record);
        wv=(WebView)findViewById(R.id.car_diary_web_view);
        final ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("Please wait..");
        progress.setMessage("Loading");
        progress.setCancelable(false);
        progress.show();
        String url = "http://"+ServerUrl.ip+"/android/showcardiarydata.php";
        String postData = null;
        try {
            postData = "vno=" + URLEncoder.encode(new SessionManager(getApplicationContext()).getUserDetails().get(SessionManager.KEY_VEHICLE_NO), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        wv.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView v,String url)
            {
                super.onPageFinished(v,url);
                progress.hide();
            }
        });
        wv.postUrl(url,postData.getBytes());
    }

}
