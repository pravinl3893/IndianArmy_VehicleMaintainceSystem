package com.vps.iavms;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity
{
    private Button login_button;
    private EditText username,password;
    private RequestQueue queue;
    public final String url = "http://"+ServerUrl.ip+"/android/login.php";
    private SessionManager sm;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        login_button=(Button)findViewById(R.id.login_activity_login_button);
        username=(EditText)findViewById(R.id.login_activity_uname);
        password=(EditText)findViewById(R.id.login_activity_password);
        queue = Volley.newRequestQueue(this);
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        sm=new SessionManager(getApplicationContext());

    }

    void login()
    {
        final ProgressDialog progress = new ProgressDialog(this);
        progress.setTitle("Please wait..");
        progress.setMessage("Logging in");
        progress.setCancelable(false); // disable dismiss by tapping outside of the dialog

        if (username.getText().toString().trim().equals("")) {
            Toast.makeText(getApplicationContext(), "Username shouldn't be empty", Toast.LENGTH_SHORT).show();
        } else if (password.getText().toString().trim().equals("")) {
            Toast.makeText(getApplicationContext(), "Enter password", Toast.LENGTH_SHORT).show();
        } else {
            final String uname = username.getText().toString();
            final String pass = password.getText().toString();
            progress.show();

            /* generating md5 for password */
            String md5_pass = null;
            try {
                MessageDigest mdEnc = MessageDigest.getInstance("MD5"); //md5 algorithm
                mdEnc.update(pass.getBytes(), 0, pass.length());
                md5_pass = new BigInteger(1, mdEnc.digest()).toString(16); // Encrypted string
            }
            catch (Exception ex) {
            }
            final String pass_word=md5_pass; //md5 password in string format

            /* Sending request to server for login */
            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response)
                        {

                            JSONObject jsonResponse = null;
                            String driver_name=null;
                            String vehicle_no=null;
                            String server_response=null;

                            // response from server
                            try
                            {
                                jsonResponse = new JSONObject(response);

                                server_response=jsonResponse.getString("server_response");
                                driver_name = jsonResponse.getString("driver_name");
                                vehicle_no=jsonResponse.getString("vehicle_number");


                            }
                            catch (Exception e)
                            {
                                Toast.makeText(getApplicationContext(),e.getLocalizedMessage(),Toast.LENGTH_LONG).show();
                            }
                            if(server_response.equals("success"))
                            {
                            sm.createUserLoginSession(driver_name,vehicle_no);
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                                Toast.makeText(getApplicationContext(), "Welcome " + new SessionManager(getApplicationContext()).getUserDetails().get(SessionManager.Key_DRIVER_NAME), Toast.LENGTH_LONG).show();
                            finish();
                            progress.dismiss();
                            }
                            else
                            {
                                progress.dismiss();
                                Toast.makeText(getApplicationContext(),"Login failed, check login information.",Toast.LENGTH_LONG).show();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            progress.dismiss();
                            Toast.makeText(getApplicationContext(), "Unable to connect to the server", Toast.LENGTH_LONG).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("name", uname);
                    params.put("pass", pass_word);

                    return params;
                }
            };
            queue.add(request);
        }
    }
}
