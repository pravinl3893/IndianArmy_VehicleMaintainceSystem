<!-- footer -->
  <br>
  <div class="footer" style="background-color: #66B2FF;">
    <div class="container">
      <div class="agile-footer-grids">
      <div class="col-md-3 w3-agile-footer-grid"></div>
        <div class="col-md-3 w3-agile-footer-grid">
          <h3 style="color:blue;">Navigation</h3>
          <ul>
            <li class="text"><a href="index.html" id="black">Home</a></li>
            <li class="text"><a href="regiments.html" id="black">Regiments </a></li>
            
            <li class="text">
                <a href="gallery.html" id="black">Gallery</a>
            </li>
            <li class="text">
                <a href="#aboutTheWebsite" id="black">About</a>
            </li>

          </ul>
        </div>
        <div class="col-md-6 w3-agile-footer-grid" style="margin-top: 50px;">
            <ul id="govLogoListCopyRight">
                <li>
                  <a href="https://india.gov.in/" target="_blank"><img src="images/india-gov-logo.jpg" style="width: 168px;height: 52px;"></a>
                </li>
                <li><p>&copy; 2017 All Rights Reserved | Government Of India <br> Powered by <a href="https://www.facebook.com/VPSSolutions-505513873143672/" target="_blank">VPSSolutions</a></p>
                </li>

            </ul>
        </div>
        
      </div>
    </div>
  </div>

  <!-- footer -->


</body>
</html>