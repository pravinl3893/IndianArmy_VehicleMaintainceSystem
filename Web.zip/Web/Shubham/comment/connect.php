<?php
$con=mysqli_connect("localhost","root","","indian_army");
?>
